package com.zeusblast.calendar

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Today
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.*
import org.json.JSONArray
import org.json.JSONObject

private val Black = Color(0xFF09090B)
private val Panel = Color(0xFF141418)
private val Red = Color(0xFFE5092F)
private val SoftRed = Color(0xFF2A0F16)
private val White = Color(0xFFF8F8F8)
private val Muted = Color(0xFF8E8E96)

data class Work(
    val date: String, val title: String, val time: String = "", val location: String = "",
    val quantity: String = "", val notes: String = ""
)

class WorkStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("zeus_calendar", Context.MODE_PRIVATE)
    fun load(): List<Work> {
        val raw = prefs.getString("works", "[]") ?: "[]"
        val arr = JSONArray(raw)
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Work(o.getString("date"), o.getString("title"), o.optString("time"),
                o.optString("location"), o.optString("quantity"), o.optString("notes"))
        }
    }
    fun save(list: List<Work>) {
        val arr = JSONArray()
        list.forEach { w ->
            arr.put(JSONObject().apply {
                put("date", w.date); put("title", w.title); put("time", w.time)
                put("location", w.location); put("quantity", w.quantity); put("notes", w.notes)
            })
        }
        prefs.edit().putString("works", arr.toString()).apply()
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ZeusTheme { ZeusCalendarApp() } }
    }
}

@Composable
fun ZeusTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Black, surface = Panel, primary = Red,
            onBackground = White, onSurface = White, onPrimary = White
        ), content = content
    )
}

@Composable
fun ZeusCalendarApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val store = remember { WorkStore(context) }
    var works by remember { mutableStateOf(store.load()) }
    var shownMonth by remember { mutableStateOf(Calendar.getInstance()) }
    var selectedDate by remember { mutableStateOf(todayKey()) }
    var showAdd by remember { mutableStateOf(false) }
    var splash by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(1200)
        splash = false
    }

    if (splash) {
        SplashScreen()
        return
    }

    val selectedWorks = works.filter { it.date == selectedDate }

    Scaffold(
        containerColor = Black,
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAdd = true },
                containerColor = Red, contentColor = White,
                shape = CircleShape
            ) { Icon(Icons.Default.Add, "Add work") }
        }
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            Header(shownMonth) { shownMonth = it }
            CalendarCard(
                shownMonth = shownMonth,
                selectedDate = selectedDate,
                works = works,
                onSelect = { selectedDate = it },
                onToday = {
                    val c = Calendar.getInstance()
                    shownMonth = c
                    selectedDate = todayKey()
                }
            )
            Spacer(Modifier.height(18.dp))
            SelectedDayHeader(selectedDate, selectedWorks.size)
            if (selectedWorks.isEmpty()) {
                EmptyDay()
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxWidth().weight(1f),
                    contentPadding = PaddingValues(start = 18.dp, end = 18.dp, bottom = 100.dp)
                ) {
                    items(selectedWorks) { work ->
                        WorkRow(work) {
                            works = works - work
                            store.save(works)
                        }
                    }
                }
            }
        }
    }

    if (showAdd) {
        AddWorkDialog(
            date = selectedDate,
            onDismiss = { showAdd = false },
            onSave = {
                works = works + it
                store.save(works)
                showAdd = false
            }
        )
    }
}

@Composable
fun SplashScreen() {
    val scale by animateFloatAsState(
        targetValue = 1f, animationSpec = tween(850, easing = FastOutSlowInEasing), label = "logo"
    )
    Box(
        Modifier.fillMaxSize().background(Black),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            androidx.compose.foundation.Image(
                painterResource(R.drawable.zeus_logo_red),
                contentDescription = "ZEUS POPPERS",
                modifier = Modifier.width(280.dp).scale(scale),
                contentScale = ContentScale.Fit
            )
            Spacer(Modifier.height(12.dp))
            Text("WORK CALENDAR", color = White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun Header(month: Calendar, onChange: (Calendar) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text("ZEUS", color = Red, fontSize = 13.sp, fontWeight = FontWeight.Black)
            Text("WORK CALENDAR", color = White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }
        IconButton(onClick = {
            val c = (month.clone() as Calendar).apply { add(Calendar.MONTH, -1) }
            onChange(c)
        }) { Icon(Icons.Default.ChevronLeft, null, tint = White) }
        IconButton(onClick = {
            val c = (month.clone() as Calendar).apply { add(Calendar.MONTH, 1) }
            onChange(c)
        }) { Icon(Icons.Default.ChevronRight, null, tint = White) }
        IconButton(onClick = {
            onChange(Calendar.getInstance())
        }) { Icon(Icons.Default.Today, null, tint = Red) }
    }
}

@Composable
fun CalendarCard(
    shownMonth: Calendar, selectedDate: String, works: List<Work>,
    onSelect: (String) -> Unit, onToday: () -> Unit
) {
    val year = shownMonth.get(Calendar.YEAR)
    val month = shownMonth.get(Calendar.MONTH)
    val first = Calendar.getInstance().apply { set(year, month, 1) }
    val days = first.getActualMaximum(Calendar.DAY_OF_MONTH)
    val start = (first.get(Calendar.DAY_OF_WEEK) + 5) % 7 // Mon=0
    val workDates = works.map { it.date }.toSet()
    val monthName = SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(first.time)

    Card(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp),
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(26.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(monthName.uppercase(), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text("${works.count { it.date.startsWith("$year-${String.format("%02d", month + 1)}") }} WORKS",
                    color = Red, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth()) {
                listOf("M","T","W","T","F","S","S").forEach {
                    Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                        Text(it, color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            for (row in 0 until 6) {
                Row(Modifier.fillMaxWidth()) {
                    for (col in 0 until 7) {
                        val index = row * 7 + col
                        val day = index - start + 1
                        if (day in 1..days) {
                            val key = String.format("%04d-%02d-%02d", year, month + 1, day)
                            DayCell(
                                day = day, isWork = workDates.contains(key),
                                isSelected = selectedDate == key, isToday = todayKey() == key,
                                modifier = Modifier.weight(1f)
                            ) { onSelect(key) }
                        } else Box(Modifier.weight(1f).height(46.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun DayCell(day: Int, isWork: Boolean, isSelected: Boolean, isToday: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Box(modifier.height(46.dp).padding(3.dp), contentAlignment = Alignment.Center) {
        val bg = when {
            isWork -> Red
            isSelected -> SoftRed
            else -> Color.Transparent
        }
        Box(
            Modifier.size(40.dp).clip(CircleShape).background(bg).clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            Text(
                "$day",
                color = if (isWork) White else if (isToday) Red else White,
                fontWeight = if (isWork || isToday) FontWeight.Bold else FontWeight.Normal
            )
        }
        if (isToday && !isWork) {
            Box(Modifier.size(5.dp).align(Alignment.BottomCenter).clip(CircleShape).background(Red))
        }
    }
}

@Composable
fun SelectedDayHeader(date: String, count: Int) {
    val parsed = runCatching {
        SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).parse(date)
    }.getOrNull()
    val title = parsed?.let { SimpleDateFormat("EEE, d MMMM", Locale.getDefault()).format(it) } ?: date
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.Event, null, tint = Red)
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(if (count == 0) "No work scheduled" else "$count work${if (count == 1) "" else "s"}", color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
fun WorkRow(work: Work, onDelete: () -> Unit) {
    Card(
        Modifier.fillMaxWidth().padding(top = 10.dp),
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(18.dp)
    ) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(4.dp, 50.dp).clip(RoundedCornerShape(4.dp)).background(Red))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(work.title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                if (work.time.isNotBlank()) Text(work.time, color = Red, fontSize = 13.sp)
                if (work.location.isNotBlank()) Text("📍 ${work.location}", color = Muted, fontSize = 12.sp)
                if (work.quantity.isNotBlank()) Text("🎉 ${work.quantity} poppers", color = Muted, fontSize = 12.sp)
                if (work.notes.isNotBlank()) Text(work.notes, color = Muted, fontSize = 12.sp)
            }
            IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, null, tint = Muted) }
        }
    }
}

@Composable
fun EmptyDay() {
    Column(
        Modifier.fillMaxWidth().padding(top = 34.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("No work on this date", color = Muted)
        Text("Tap + to add a booking", color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun AddWorkDialog(date: String, onDismiss: () -> Unit, onSave: (Work) -> Unit) {
    var title by remember { mutableStateOf("") }
    var time by remember { mutableStateOf("") }
    var location by remember { mutableStateOf("") }
    var quantity by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Work") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Date: $date", color = Red, fontWeight = FontWeight.Bold)
                SmallField("Event / Customer", title) { title = it }
                SmallField("Time", time) { time = it }
                SmallField("Location", location) { location = it }
                SmallField("Poppers", quantity) { quantity = it }
                SmallField("Notes", notes) { notes = it }
            }
        },
        confirmButton = {
            TextButton(
                enabled = title.isNotBlank(),
                onClick = { onSave(Work(date, title, time, location, quantity, notes)) }
            ) { Text("SAVE", color = Red, fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("CANCEL") } }
    )
}

@Composable
fun SmallField(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) },
        singleLine = true, modifier = Modifier.fillMaxWidth()
    )
}

fun todayKey(): String = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
