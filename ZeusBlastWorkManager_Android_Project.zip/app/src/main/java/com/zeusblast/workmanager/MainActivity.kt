package com.zeusblast.workmanager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.PendingActions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import java.text.SimpleDateFormat
import java.util.*

data class Work(
    val id: Long = System.currentTimeMillis(),
    val event: String,
    val date: String,
    val time: String,
    val location: String,
    val quantity: String,
    val amount: String,
    val notes: String,
    val completed: Boolean = false
)

class WorkViewModel : ViewModel() {
    var works by mutableStateOf(listOf<Work>())
        private set

    fun add(work: Work) { works = works + work }
    fun toggle(id: Long) { works = works.map { if (it.id == id) it.copy(completed = !it.completed) else it } }
    fun delete(id: Long) { works = works.filterNot { it.id == id } }
}

private val Bg = Color(0xFF0B0B0F)
private val Card = Color(0xFF15151C)
private val Accent = Color(0xFFFF304F)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ZeusTheme {
                val vm = remember { WorkViewModel() }
                ZeusApp(vm)
            }
        }
    }
}

@Composable
fun ZeusTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg,
            surface = Card,
            primary = Accent,
            onBackground = Color.White,
            onSurface = Color.White
        ),
        content = content
    )
}

@Composable
fun ZeusApp(vm: WorkViewModel) {
    var tab by remember { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = Bg,
        floatingActionButton = {
            if (tab == 0) FloatingActionButton(
                onClick = { showAdd = true },
                containerColor = Accent,
                contentColor = Color.White
            ) { Icon(Icons.Default.Add, "Add work") }
        },
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF111116)) {
                NavigationBarItem(tab == 0, { tab = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") })
                NavigationBarItem(tab == 1, { tab = 1 }, icon = { Icon(Icons.Default.CalendarMonth, null) }, label = { Text("Calendar") })
                NavigationBarItem(tab == 2, { tab = 2 }, icon = { Icon(Icons.Default.CheckCircle, null) }, label = { Text("Done") })
            }
        }
    ) { pad ->
        when (tab) {
            0 -> HomeScreen(vm, Modifier.padding(pad))
            1 -> CalendarScreen(vm, Modifier.padding(pad))
            2 -> CompletedScreen(vm, Modifier.padding(pad))
        }
    }

    if (showAdd) AddWorkDialog(
        onDismiss = { showAdd = false },
        onSave = { vm.add(it); showAdd = false }
    )
}

@Composable
fun Header() {
    Column(Modifier.padding(horizontal = 20.dp, vertical = 18.dp)) {
        Text("ZEUS BLAST", color = Accent, fontWeight = FontWeight.Black)
        Text("WORK MANAGER", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun HomeScreen(vm: WorkViewModel, modifier: Modifier = Modifier) {
    val pending = vm.works.count { !it.completed }
    val done = vm.works.count { it.completed }
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 90.dp)) {
        item {
            Header()
            Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("UPCOMING", pending.toString())
                StatCard("COMPLETED", done.toString())
                StatCard("TOTAL", vm.works.size.toString())
            }
            Spacer(Modifier.height(18.dp))
            Text("Upcoming Works", Modifier.padding(horizontal = 20.dp), fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
        }
        items(vm.works.filter { !it.completed }) { work ->
            WorkCard(work, { vm.toggle(work.id) }, { vm.delete(work.id) })
        }
        if (vm.works.none { !it.completed }) item {
            EmptyState("No upcoming works", "Tap + to add your first booking.")
        }
    }
}

@Composable
fun StatCard(title: String, value: String) {
    Card(
        Modifier.weight(1f),
        colors = CardDefaults.cardColors(containerColor = Card),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text(title, style = MaterialTheme.typography.labelSmall, color = Color.LightGray)
        }
    }
}

@Composable
fun WorkCard(work: Work, onToggle: () -> Unit, onDelete: () -> Unit) {
    Card(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
        colors = CardDefaults.cardColors(containerColor = Card),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(work.event, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Text("${work.date}  •  ${work.time}", color = Accent)
                }
                IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, "Delete") }
            }
            Spacer(Modifier.height(8.dp))
            Text("📍 ${work.location}")
            Text("🎉 ${work.quantity} poppers")
            if (work.amount.isNotBlank()) Text("₹ ${work.amount}")
            if (work.notes.isNotBlank()) Text(work.notes, color = Color.LightGray)
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = onToggle) {
                Icon(if (work.completed) Icons.Default.PendingActions else Icons.Default.CheckCircle, null)
                Spacer(Modifier.width(6.dp))
                Text(if (work.completed) "Mark Pending" else "Mark Completed")
            }
        }
    }
}

@Composable
fun CalendarScreen(vm: WorkViewModel, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize()) {
        Header()
        Text("All scheduled works", Modifier.padding(horizontal = 20.dp), fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        LazyColumn(contentPadding = PaddingValues(bottom = 90.dp)) {
            items(vm.works.sortedBy { it.date }) { work ->
                WorkCard(work, { vm.toggle(work.id) }, { vm.delete(work.id) })
            }
        }
    }
}

@Composable
fun CompletedScreen(vm: WorkViewModel, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize()) {
        Header()
        Text("Completed Works", Modifier.padding(horizontal = 20.dp), fontWeight = FontWeight.Bold)
        LazyColumn(contentPadding = PaddingValues(bottom = 90.dp)) {
            items(vm.works.filter { it.completed }) { work ->
                WorkCard(work, { vm.toggle(work.id) }, { vm.delete(work.id) })
            }
        }
    }
}

@Composable
fun EmptyState(title: String, subtitle: String) {
    Column(
        Modifier.fillMaxWidth().padding(50.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(title, fontWeight = FontWeight.Bold)
        Text(subtitle, color = Color.Gray)
    }
}

@Composable
fun AddWorkDialog(onDismiss: () -> Unit, onSave: (Work) -> Unit) {
    var event by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date())) }
    var time by remember { mutableStateOf("7:00 PM") }
    var location by remember { mutableStateOf("") }
    var quantity by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add New Work") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Field("Event name", event) { event = it }
                Field("Date", date) { date = it }
                Field("Time", time) { time = it }
                Field("Location", location) { location = it }
                Field("Popper quantity", quantity) { quantity = it }
                Field("Amount", amount) { amount = it }
                Field("Notes", notes) { notes = it }
            }
        },
        confirmButton = {
            TextButton(
                enabled = event.isNotBlank() && date.isNotBlank(),
                onClick = {
                    onSave(Work(event, date, time, location, quantity, amount, notes))
                }
            ) { Text("SAVE", color = Accent) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("CANCEL") } }
    )
}

@Composable
fun Field(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth()
    )
}
